function calculateAge() {
    const day = parseInt(document.getElementById('day').value);
    const month = parseInt(document.getElementById('month').value);
    const year = parseInt(document.getElementById('year').value);

    const currentYear = new Date().getFullYear();

    if (!day || day < 1 || day > 31) {
        document.getElementById('result').innerText = 'Please enter a valid day between 1 and 31.';
        return;
    }

    if (!month || month < 1 || month > 12) {
        document.getElementById('result').innerText = 'Please enter a valid month between 1 and 12.';
        return;
    }

    if (!year || year < 1900 || year > currentYear) {
        document.getElementById('result').innerText = `Please enter a valid year between 1900 and ${currentYear}.`;
        return;
    }

    const dob = new Date(year, month - 1, day);
    const diff_ms = Date.now() - dob.getTime();
    const age_dt = new Date(diff_ms);

    const age = Math.abs(age_dt.getUTCFullYear() - 1970);

    document.getElementById('result').innerText = `Your age is ${age} years.`;
}